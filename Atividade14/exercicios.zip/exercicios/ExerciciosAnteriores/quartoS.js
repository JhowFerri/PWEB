const fs = require('fs');
const data = fs.readFileSync('file.txt');
//execucao bloqueada ate o arquivo ser lido
console.log(data.toString());